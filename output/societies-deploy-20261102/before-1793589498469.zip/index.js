'use strict';
const cloud = require('wx-server-sdk');
const { resolveUser, authenticate } = require('./lib/auth');
const publicApi = require('./lib/public');
const applications = require('./lib/applications');
const members = require('./lib/members');
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });
const db = cloud.database({ throwOnNotFound: false });
const publicActions = new Set(['home', 'list', 'detail', 'profile', 'opportunity']);
const handlers = {
  home: (user) => publicApi.home(db, user),
  list: (user, event) => publicApi.listSocieties(db, event),
  detail: (user, event) => publicApi.detail(db, user, event),
  profile: (user, event) => publicApi.profile(db, user, event),
  opportunity: (user, event) => publicApi.opportunity(db, event),
  myApplication: (user) => applications.myApplication(db, user),
  submitApplication: (user, event) => applications.submitApplication(db, user, event),
  listApplications: (user, event) => applications.listApplications(db, cloud, user, event),
  reviewApplication: (user, event) => applications.reviewApplication(db, user, event),
  follow: (user, event) => members.follow(db, user, event),
  applyJoin: (user, event) => members.applyJoin(db, user, event),
  cancelJoin: (user, event) => members.cancelJoin(db, user, event),
  manage: (user, event) => members.manage(db, user, event),
  reviewJoin: (user, event) => members.reviewJoin(db, user, event),
  mine: (user) => members.mine(db, user)
};
exports.main = async (event = {}) => {
  try {
    if (event.action === 'authenticate') return { success: true, ...await authenticate(db, cloud, event) };
    if (!Object.prototype.hasOwnProperty.call(handlers, event.action)) return { success: false, code: 'INVALID_ACTION', message: '不支持的诗社操作' };
    const user = await resolveUser(db, event, cloud.getWXContext(), !publicActions.has(event.action));
    return { success: true, ...await handlers[event.action](user, event) };
  } catch (error) {
    // Never log passwords, session tokens, contact details, evidence URLs, or raw database errors.
    console.error('[societyManager]', event.action, error.code || 'SERVICE_ERROR');
    return { success: false, code: error.code || 'SERVICE_ERROR', message: error.code ? error.message : '诗社服务暂时不可用，请稍后重试' };
  }
};
